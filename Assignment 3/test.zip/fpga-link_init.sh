cd C:/makestuff/libs/libfpgalink-20120621
./win32/rel/flcli -v 1443:0007 -i 1443:0007 -s -x C:/Users/Joy\ Chopra/Lab8/Lab8.xsvf

